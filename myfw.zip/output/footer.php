<link rel="stylesheet" href="/myfw/public/css/footer.css">
<div class="footer">
  <p>d33ma$ik</p>
</div>